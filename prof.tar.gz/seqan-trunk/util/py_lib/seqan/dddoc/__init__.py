#!/usr/bin/env python

import main as m
import sys

def main():
    sys.exit(m.main(sys.argv))
